# broke-mobile
School project where we create a eCommerce like desktop application

Giorgi Alvarez Testing
